'use strict'

module.exports = (obj) => obj || []
